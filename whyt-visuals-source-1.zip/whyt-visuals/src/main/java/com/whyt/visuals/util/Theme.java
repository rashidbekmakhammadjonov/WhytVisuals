package com.whyt.visuals.util;

import com.whyt.visuals.module.ThemeModule;

import java.awt.Color;

public final class Theme {
    private Theme() {}
    public static ThemeModule module;

    /** Accent color (ARGB), optional offset in ms-equivalent for rainbow gradients. */
    public static int accent(int offset) {
        float hue;
        if (module != null && module.rainbow.bool()) {
            double speed = Math.max(1, module.speed.num());
            hue = (float) (((System.currentTimeMillis() / (60.0 / speed)) + offset) % 3600 / 3600.0);
        } else {
            hue = (float) ((module == null ? 200 : module.hue.num()) / 360.0);
        }
        return 0xFF000000 | Color.HSBtoRGB(hue, 0.6f, 1f);
    }

    public static int accent() { return accent(0); }
}

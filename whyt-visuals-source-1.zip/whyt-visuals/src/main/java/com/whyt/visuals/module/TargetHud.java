package com.whyt.visuals.module;

import com.whyt.visuals.util.Render;
import com.whyt.visuals.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

public class TargetHud extends HudModule {
    public static LivingEntity target;
    public static long targetTime;
    private float shownHealth = -1;

    public TargetHud() { super("TargetHud", "Health of the last entity you hit", 300, 200); setEnabled(true); }

    @Override
    public void onRender(DrawContext ctx) {
        if (target == null || !target.isAlive() || System.currentTimeMillis() - targetTime > 4000) {
            shownHealth = -1;
            return;
        }
        float max = Math.max(1f, target.getMaxHealth());
        float hp = MathHelper.clamp(target.getHealth(), 0, max);
        shownHealth = shownHealth < 0 ? hp : shownHealth + (hp - shownHealth) * 0.15f;

        var tr = mc.textRenderer;
        String name = target.getName().getString();
        int w = Math.max(110, tr.getWidth(name) + 16), h = 32;
        int x = x(), y = y();
        Render.roundedBox(ctx, x, y, w, h, 0xB0101014);
        ctx.drawTextWithShadow(tr, name, x + 8, y + 6, 0xFFFFFFFF);
        int bx = x + 8, by = y + 20, bw = w - 16;
        ctx.fill(bx, by, bx + bw, by + 5, 0xFF2A2A32);
        ctx.fill(bx, by, bx + (int) (bw * (shownHealth / max)), by + 5, Theme.accent());
        String hpText = String.format(java.util.Locale.ROOT, "%.1f", hp);
        ctx.drawTextWithShadow(tr, hpText, x + w - 8 - tr.getWidth(hpText), y + 6, 0xFFB8B8C0);
    }
}

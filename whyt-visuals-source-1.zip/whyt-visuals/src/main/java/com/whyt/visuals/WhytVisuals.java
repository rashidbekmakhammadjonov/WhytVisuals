package com.whyt.visuals;

import com.whyt.visuals.gui.ClickGuiScreen;
import com.whyt.visuals.module.ModuleManager;
import com.whyt.visuals.module.TargetHud;
import com.whyt.visuals.util.Config;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class WhytVisuals implements ClientModInitializer {
    public static final String CATEGORY = "key.categories.whytvisuals";
    public static ModuleManager modules;
    public static KeyBinding guiKey;
    public static KeyBinding zoomKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        Config.load(modules);

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.whytvisuals.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.whytvisuals.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            modules.tick();
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            var mc = net.minecraft.client.MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;
            modules.render(ctx);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient) {
                if (entity instanceof LivingEntity le) {
                    TargetHud.target = le;
                    TargetHud.targetTime = System.currentTimeMillis();
                }
                if (modules.hitParticles.enabled) modules.hitParticles.spawn(entity);
            }
            return ActionResult.PASS;
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> Config.save(modules));
    }
}

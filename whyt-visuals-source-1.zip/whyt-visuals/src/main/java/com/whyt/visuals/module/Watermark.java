package com.whyt.visuals.module;

import com.whyt.visuals.setting.Setting;
import com.whyt.visuals.util.Render;
import com.whyt.visuals.util.Theme;
import net.minecraft.client.gui.DrawContext;

public class Watermark extends HudModule {
    private final Setting showName = add(Setting.bool("Username", true));
    private final Setting showFps = add(Setting.bool("FPS", true));

    public Watermark() { super("Watermark", "Client name bar", 6, 6); setEnabled(true); }

    @Override
    public void onRender(DrawContext ctx) {
        var tr = mc.textRenderer;
        StringBuilder sb = new StringBuilder();
        if (showName.bool() && mc.player != null) sb.append("  |  ").append(mc.getSession().getUsername());
        if (showFps.bool()) sb.append("  |  ").append(mc.getCurrentFps()).append(" fps");
        String title = "Whyt";
        String sub = " Visuals";
        int w = tr.getWidth(title) + tr.getWidth(sub) + tr.getWidth(sb.toString()) + 12;
        int x = x(), y = y(), h = 16;
        Render.roundedBox(ctx, x, y, w, h, 0xB0101014);
        ctx.fill(x + 1, y, x + w - 1, y + 1, Theme.accent());
        int tx = x + 6;
        ctx.drawTextWithShadow(tr, title, tx, y + 4, Theme.accent(0));
        tx += tr.getWidth(title);
        ctx.drawTextWithShadow(tr, sub, tx, y + 4, 0xFFFFFFFF);
        tx += tr.getWidth(sub);
        ctx.drawTextWithShadow(tr, sb.toString(), tx, y + 4, 0xFFB8B8C0);
    }
}

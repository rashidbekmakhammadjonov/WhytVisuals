package com.whyt.visuals.module;

import com.whyt.visuals.util.Theme;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();
    public final HitParticles hitParticles = new HitParticles();

    public ModuleManager() {
        ThemeModule theme = new ThemeModule();
        Theme.module = theme;
        modules.add(new Watermark());
        modules.add(new Info());
        modules.add(new Keystrokes());
        modules.add(new ArmorHud());
        modules.add(new TargetHud());
        modules.add(new Fullbright());
        modules.add(new Zoom());
        modules.add(hitParticles);
        modules.add(theme);
    }

    public List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        return out;
    }

    public void tick() {
        for (Module m : modules) if (m.enabled) m.onTick();
    }

    public void render(DrawContext ctx) {
        for (Module m : modules) if (m.enabled) m.onRender(ctx);
    }
}

package com.whyt.visuals.module;

public enum Category {
    HUD("HUD"), RENDER("Render"), CLIENT("Client");

    public final String label;
    Category(String label) { this.label = label; }
}

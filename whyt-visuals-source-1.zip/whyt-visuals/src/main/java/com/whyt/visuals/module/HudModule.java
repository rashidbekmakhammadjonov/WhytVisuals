package com.whyt.visuals.module;

import com.whyt.visuals.setting.Setting;

/** A module drawn on the HUD with configurable X/Y position. */
public abstract class HudModule extends Module {
    private final Setting x, y;

    protected HudModule(String name, String description, int defX, int defY) {
        super(name, description, Category.HUD);
        x = add(Setting.num("X", defX, 0, 1920, 1));
        y = add(Setting.num("Y", defY, 0, 1080, 1));
    }

    protected int x() { return x.intVal(); }
    protected int y() { return y.intVal(); }
}

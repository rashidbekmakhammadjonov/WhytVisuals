package com.whyt.visuals.module;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHud extends HudModule {
    private static final EquipmentSlot[] SLOTS = {
        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public ArmorHud() { super("ArmorHud", "Armor and held item with durability", 6, 160); }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.player == null) return;
        int x = x(), y = y();
        for (EquipmentSlot slot : SLOTS) {
            ItemStack st = mc.player.getEquippedStack(slot);
            if (!st.isEmpty()) {
                ctx.drawItem(st, x, y);
                ctx.drawStackOverlay(mc.textRenderer, st, x, y);
                y += 18;
            }
        }
        ItemStack hand = mc.player.getMainHandStack();
        if (!hand.isEmpty()) {
            ctx.drawItem(hand, x, y);
            ctx.drawStackOverlay(mc.textRenderer, hand, x, y);
        }
    }
}

package com.whyt.visuals.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.whyt.visuals.module.Module;
import com.whyt.visuals.module.ModuleManager;
import com.whyt.visuals.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("whyt-visuals.json");

    private Config() {}

    public static void save(ModuleManager mm) {
        JsonObject root = new JsonObject();
        for (Module m : mm.modules) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.enabled);
            JsonObject s = new JsonObject();
            for (Setting st : m.settings) s.addProperty(st.name, st.value);
            o.add("settings", s);
            root.add(m.name, o);
        }
        try (Writer w = Files.newBufferedWriter(FILE)) {
            GSON.toJson(root, w);
        } catch (Exception e) {
            System.err.println("[Whyt Visuals] Failed to save config: " + e);
        }
    }

    public static void load(ModuleManager mm) {
        if (!Files.exists(FILE)) return;
        try (Reader r = Files.newBufferedReader(FILE)) {
            JsonObject root = GSON.fromJson(r, JsonObject.class);
            if (root == null) return;
            for (Module m : mm.modules) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("enabled") && m != Theme.module) m.setEnabled(o.get("enabled").getAsBoolean());
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting st : m.settings) if (s.has(st.name)) st.set(s.get(st.name).getAsDouble());
                }
            }
        } catch (Exception e) {
            System.err.println("[Whyt Visuals] Failed to load config: " + e);
        }
    }
}

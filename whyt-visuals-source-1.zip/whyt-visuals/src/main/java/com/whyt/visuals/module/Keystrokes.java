package com.whyt.visuals.module;

import com.whyt.visuals.util.Render;
import com.whyt.visuals.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

public class Keystrokes extends HudModule {
    public Keystrokes() { super("Keystrokes", "WASD and jump display", 6, 100); }

    private void key(DrawContext ctx, int x, int y, int w, int h, String label, KeyBinding k) {
        boolean down = k.isPressed();
        Render.roundedBox(ctx, x, y, w, h, down ? Render.alpha(Theme.accent(), 0xB0) : 0x90101014);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawTextWithShadow(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }

    @Override
    public void onRender(DrawContext ctx) {
        var o = mc.options;
        int x = x(), y = y(), s = 20, g = 2;
        key(ctx, x + s + g, y, s, s, "W", o.forwardKey);
        key(ctx, x, y + s + g, s, s, "A", o.leftKey);
        key(ctx, x + s + g, y + s + g, s, s, "S", o.backKey);
        key(ctx, x + 2 * (s + g), y + s + g, s, s, "D", o.rightKey);
        key(ctx, x, y + 2 * (s + g), 3 * s + 2 * g, 14, "SPACE", o.jumpKey);
    }
}

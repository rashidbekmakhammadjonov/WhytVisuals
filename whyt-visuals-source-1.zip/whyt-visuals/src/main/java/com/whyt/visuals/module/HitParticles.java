package com.whyt.visuals.module;

import com.whyt.visuals.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

public class HitParticles extends Module {
    private final Setting type = add(Setting.mode("Type", "Crit", "Enchant", "Heart", "End Rod"));
    private final Setting amount = add(Setting.num("Amount", 8, 1, 30, 1));

    public HitParticles() { super("HitParticles", "Extra particles when you hit something", Category.RENDER); }

    public void spawn(Entity e) {
        if (mc.world == null) return;
        ParticleEffect p = switch (type.mode()) {
            case "Enchant" -> ParticleTypes.ENCHANTED_HIT;
            case "Heart" -> ParticleTypes.HEART;
            case "End Rod" -> ParticleTypes.END_ROD;
            default -> ParticleTypes.CRIT;
        };
        var r = mc.world.random;
        for (int i = 0; i < amount.intVal(); i++) {
            double x = e.getX() + (r.nextDouble() - 0.5) * e.getWidth();
            double y = e.getY() + r.nextDouble() * e.getHeight();
            double z = e.getZ() + (r.nextDouble() - 0.5) * e.getWidth();
            mc.world.addParticle(p, x, y, z, (r.nextDouble() - 0.5) * 0.3, r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.3);
        }
    }
}
